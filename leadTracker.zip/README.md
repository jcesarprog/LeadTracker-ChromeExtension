# Lead Tracker 

## It's a simple chrome extension that lets you save any text or the current URL from the current chrome tab in a persistent list